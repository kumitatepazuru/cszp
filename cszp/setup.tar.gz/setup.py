import sys,subprocess,urllib.request
try:
    argv2 = sys.argv[1]
except:
    argv2 = "/opt"

print("file downloading...")
urllib.request.urlretrieve("https://github.com/kumitatepazuru/blog/raw/master/data/cszp-101/cszp.tar.gz", "/tmp/cszp.tar.gz")
print("During unzip the file...")
#passwd = (getpass.getpass() + '\n').encode()
subprocess.check_output("sudo mkdir "+argv2+"/cszp && sudo tar xzvf /tmp/cszp.tar.gz -C "+argv2+"/cszp", shell=True)
subprocess.check_output("sudo bash -c 'echo cd "+argv2+"/cszp/ > "+argv2+"/cszp/cszp.sh && echo python3 "+argv2+"/cszp/main.py >> "+argv2+"/cszp/cszp.sh && chmod 777 "+argv2+"/cszp/cszp.sh && ln -s "+argv2+"/cszp/cszp.sh /usr/bin/cszp'",shell=True)
print("completed!")
